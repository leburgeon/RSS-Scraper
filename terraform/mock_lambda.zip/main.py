import json

def lambda_handler(event, context):
    # In a real scenario, you would parse event.get('body') here
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps({
            "response": "This is a static mock response from the c22 RAG Lambda!"
        })
    }
